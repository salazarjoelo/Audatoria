DROP TABLE IF EXISTS `#__audatoria_channels`;
DROP TABLE IF EXISTS `#__audatoria_items`;
DROP TABLE IF EXISTS `#__audatoria_timelines`;